﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;

namespace DrinkUp.WebApi.Model.Identity {
    public class User : IdentityUser{
        
    }
}