﻿namespace DrinkUp.WebApi.ViewModels {
    public class SearchViewModel {
        public string SearchPhase { get; set; }
    }
}