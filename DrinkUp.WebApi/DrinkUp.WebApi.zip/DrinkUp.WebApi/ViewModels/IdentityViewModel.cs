﻿namespace DrinkUp.WebApi.ViewModels {
    public class IdentityViewModel {
        public string Id { get; set; }
    }
}
