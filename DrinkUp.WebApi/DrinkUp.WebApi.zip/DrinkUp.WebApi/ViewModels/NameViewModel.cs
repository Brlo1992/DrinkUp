﻿namespace DrinkUp.WebApi.ViewModels {
    public class NameViewModel {
        public string Name { get; set; }
    }
}