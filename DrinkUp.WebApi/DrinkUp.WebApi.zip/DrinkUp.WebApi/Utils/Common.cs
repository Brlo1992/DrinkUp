﻿namespace DrinkUp.WebApi.Utils {
    public static class Common {
        public static bool IsNotNull(object instance) => instance != null;
    }
}