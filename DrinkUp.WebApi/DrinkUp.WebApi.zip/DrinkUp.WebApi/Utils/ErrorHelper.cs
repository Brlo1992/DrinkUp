﻿namespace DrinkUp.WebApi.Utils {
    public class ErrorHelper
    {
        public const string LoginFailed = "Login failed";
    }
}
